﻿Imports System.Data
Imports System.IO
Public Class VehicleDealerTrack
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        vehicletxt.Visible = False
        Vehiclename.Visible = False
    End Sub
    Protected Sub import_Click(sender As Object, e As EventArgs) Handles import.Click

        Dim csv As String = Server.MapPath("~/Files/") + Path.GetFileName(fileupload.PostedFile.FileName)
        fileupload.SaveAs(csv)


        Dim dt As New DataTable

        dt.Columns.AddRange(New DataColumn(5) {New DataColumn("DealNumber", GetType(String)), New DataColumn("Customer", GetType(String)), New DataColumn("DealershipName", GetType(String)), New DataColumn("Vehicle", GetType(String)), New DataColumn("Price", GetType(String)), New DataColumn("Date", GetType(String))})
        'dt.Columns.AddRange(New DataColumn(5))
        Dim readcsv As String = File.ReadAllText(csv)
        Dim dollar As String = "CAD$"
        For Each row As String In readcsv.Split(ControlChars.Lf)

            If Not (String.IsNullOrEmpty(row)) Then
                dt.Rows.Add()
                If Not (dt.Rows.Count = 1) Then

                    Dim i As Integer = 0

                    For Each cell As String In row.Split(","c)
                        If (i = 4) Then
                            dt.Rows(dt.Rows.Count - 1)(i) = dollar + cell

                        Else
                            dt.Rows(dt.Rows.Count - 1)(i) = cell
                        End If

                        System.Console.WriteLine("dt.Rows(dt.Rows.Count - 1)(i)::", dt.Rows(dt.Rows.Count - 1)(i))
                        i += 1

                    Next


                End If

            End If

        Next


        GridView1.DataSource = dt
        GridView1.DataBind()

        'To find the vehicle sold most often by deal number
        Vehicle_Sold(dt)
    End Sub

    Sub Vehicle_Sold(ByVal dt As DataTable)

        If (dt.Columns(0).ColumnName = "DealNumber") Then
            Dim dealnumber As Integer = dt.Rows(1)(0)
            Dim Vehiclerow As String = 2
            For row1 As Integer = 2 To dt.Rows.Count - 1

                If (dealnumber > dt.Rows(row1)(0)) Then
                    dealnumber = dealnumber

                Else
                    dealnumber = dt.Rows(row1)(0)
                    Vehiclerow = row1
                End If

            Next
            vehicletxt.Visible = True
            Vehiclename.Visible = True

            Vehiclename.Text = dt.Rows(Vehiclerow)(3)

        End If


    End Sub

End Class